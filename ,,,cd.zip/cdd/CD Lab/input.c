#include <stdio.h>
/* this the program*/
int main(int argc, char *argv[])
{
	//begin
	printf("Hello, world\n");
	
	return 0;
	//end
}
