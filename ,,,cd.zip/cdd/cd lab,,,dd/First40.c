#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int np=0,n=0;
char prod[10][10],res[10];
void first(char);
int main()
{
	int i,c;
	char s,ch;
	printf("Enter no.of productions:");
	scanf("%d",&np);
	for(i=0;i<np;i++)
	{
		scanf("%s%c",prod[i],&s);
	}
	do{
		n=0;
		printf("Find First of:");
		scanf("%c",&ch);
		first(ch);
		printf("First(%c): {",ch);
		for(i=0;i<n;i++)
		{
			printf("%c ,",res[i]);
		}
		printf("}\n");
		printf("Enter 1 to continue:");
		scanf("%d%c",&c,&s);
	}while(c==1);
}
void first(char ch)
{
	int i;
	if(!(isupper(ch)))
		res[n++]=ch;
	for(i=0;i<np;i++)
	{
		if(prod[i][0]==ch)
		{
			if(prod[i][2]=='#')
				res[n++]=prod[i][2];
			else if(islower(prod[i][2]))
				res[n++]=prod[i][2];
			else
				first(prod[i][2]);
		}
	}
}
